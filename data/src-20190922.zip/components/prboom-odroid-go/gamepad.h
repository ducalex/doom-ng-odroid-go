void gamepadInit(void);
void gamepadPoll(void);
