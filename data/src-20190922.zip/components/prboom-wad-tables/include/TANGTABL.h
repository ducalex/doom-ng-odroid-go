extern const unsigned char TANGTABL_dat[];
extern unsigned int TANGTABL_dat_len;
