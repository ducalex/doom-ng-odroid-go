extern const unsigned char GAMMATBL_dat[];
extern unsigned int GAMMATBL_dat_len;
