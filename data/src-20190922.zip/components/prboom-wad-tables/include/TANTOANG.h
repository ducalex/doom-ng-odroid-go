extern const unsigned char TANTOANG_dat[];
extern unsigned int TANTOANG_dat_len;
