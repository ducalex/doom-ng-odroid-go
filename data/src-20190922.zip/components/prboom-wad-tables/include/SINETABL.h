extern const unsigned char SINETABL_dat[];
extern unsigned int SINETABL_dat_len;
